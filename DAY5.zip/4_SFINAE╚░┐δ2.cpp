#include <iostream>
#include <string>
#include <vector>

class People
{
	std::string name;
	std::string addr;
public:
	template<typename T1, typename T2>
	People(T1&& s1, T2&& s2)
		: name(std::forward<T1>(s1)), addr(std::forward<T2>(s2))  // ok.. ����!
	{
	}
};


int main()
{
	std::string s1 = "kim";

	People p1(s1, 30);
}

















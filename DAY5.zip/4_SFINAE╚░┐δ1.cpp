// 1_move14-1
#include <iostream>
#include <string>
#include <vector>

class People
{
	std::string name;
	std::string addr;
public:
	// ��� 1. 2�� ������
//	void setName(const std::string& r) { name = r; }
//	void setName(std::string&& r) { name = std::move(r); }

	// ��� 2. forwarding reference
	template<typename T>
	void setName(T&& arg)
	{
		name = std::forward<T>(arg);
	}
};

int main()
{
	People p;
	
	p.setName("kim");
	p.setName(20);

}
















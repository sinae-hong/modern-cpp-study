
int main()
{
	foo( [](int a, int b) {return a + b; } );
	foo([](int a, int b) {return a + b; });
}



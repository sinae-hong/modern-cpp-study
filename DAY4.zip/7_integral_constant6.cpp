#include <iostream>



int main()
{

}
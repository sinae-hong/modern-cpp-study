#include <iostream>

// 129 page
struct plus
{
	int operator()(int a, int b) const 
	{
		return a + b;
	}
};

int main()
{
	plus p;	

	int n = p(1, 2);
}
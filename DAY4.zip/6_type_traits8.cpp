#include <iostream>
#include <type_traits>

int main()
{
	int n = 10;

	n + 1 = 10;
	(n = 10) = 20;
	++n = 10;
	n++ = 10;
}
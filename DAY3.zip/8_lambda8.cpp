#include <iostream>

// �������� ĸ��  - 146page

int g = 10;

int main()
{
	int v1 = 10, v2 = 10;

	auto f1 = [](int a) { return a; };
	auto f2 = [](int a) { return a; };
	auto f3 = [](int a) { return a; };
	auto f4 = [](int a) { return a; };

}
#include <iostream>

// generic lambda
int main()
{
	auto add1 = [](int a, int b) { return a + b; };

	std::cout << add1(1,   2)   << std::endl;
	std::cout << add1(1.1, 2.2) << std::endl;
}
// move13
#include <iostream>
#include <string>

// const �� move

int main()
{
	std::string s1 = "hello";
	std::string s2 = std::move(s1);

	std::cout << s1 << std::endl;
}
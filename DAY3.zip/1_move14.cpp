#include <iostream>
#include <string>

class People
{
	std::string name;
	std::string addr;
public:
	void setName(const std::string& s) { name = s; }
};

int main()
{
	People p;

	std::string s = "kim";
	p.setName(s);
	p.setName(std::move(s));
}






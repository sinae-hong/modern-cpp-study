#include <iostream>

// ��� ����Ÿ ĸ�� - 150
class Test
{
	int data;
public:
	void foo()
	{
		auto f = [](int a) { return a + data; }; // ??

		f(10);
	}
};

int main()
{
	Test t;
	t.foo();
}